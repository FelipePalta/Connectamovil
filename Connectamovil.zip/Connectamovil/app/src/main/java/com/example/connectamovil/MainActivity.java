package com.example.connectamovil;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verifica si el usuario está autenticado
        if (usuarioAutenticado()) {
            iniciarActividad(ContactsActivity.class);
        } else {
            iniciarActividad(LoginActivity.class);
        }
        finish();
    }

    private boolean usuarioAutenticado() {
        // Implementa lógica de Firebase Authentication
        FirebaseUser currentUser = mAuth.getCurrentUser();

        // Retorna true si el usuario está autenticado, false de lo contrario
        return false;
    }

    private void iniciarActividad(Class<?> clase) {
        Intent intent = new Intent(this, clase);
        startActivity(intent);
    }
    }
